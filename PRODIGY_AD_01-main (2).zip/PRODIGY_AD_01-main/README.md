# PRODIGY_AD_01
Build a calculator app that can perform basic arithmetic operations in Flutter
